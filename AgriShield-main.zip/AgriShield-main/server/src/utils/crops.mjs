export const cropsArray = [
  'Banana', 'Maize', 'Apple', 'Wheat', 'Black Gram (Urd Beans)(Whole)',
  'Bengal Gram(Gram)(Whole)', 'Paddy(Dhan)(Common)', 'Ginger(Green)',
  'Green Chilli', 'Pomegranate', 'Tomato', 'Onion', 'Potato',
  'Mustard', 'Masur Dal', 'Garlic', 'Rice', 'Arhar (Tur/Red Gram)(Whole)',
  'Lentil (Masur)(Whole)', 'Groundnut', 'Capsicum', 'Spinach', 'Papaya',
  'Water Melon', 'Carrot', 'Cauliflower', 'Orange', 'Peas Wet', 
  'Pineapple', 'Green Peas', 'Amla(Nelli Kai)', 'Chikoos(Sapota)', 
  'Bajra(Pearl Millet/Cumbu)', 'Jowar(Sorghum)', 'Turmeric', 
  'Soyabean', 'Cotton', 'Moath Dal', 'Peach', 'Turnip', 
  'Cummin Seed(Jeera)', 'Mint(Pudina)', 'Guar Seed(Cluster Beans Seed)', 
  'Kodo Millet(Varagu)'
];
