import React from 'react'

const About :React.FC= () => {
  return (
    <div>About</div>
  )
}

export default About